import type { Metadata } from "next";
import { Figtree, Instrument_Serif } from "next/font/google";
import "./globals.css";

const display = Instrument_Serif({ subsets: ["latin"], variable: "--font-display", weight: "400", style: ["normal", "italic"] });
const body = Figtree({ subsets: ["latin"], variable: "--font-body" });

const siteUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "Temurjon Kholmirzaev: systems engineering, heading toward game AI",
  description: "Integrated Systems Engineering student at Inha University building agents, perception systems, and data systems.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "Temurjon Kholmirzaev",
    description: "Agents, perception, and systems projects by an Integrated Systems Engineering student at Inha University.",
    type: "website",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className={`${display.variable} ${body.variable}`}><body>{children}</body></html>;
}
