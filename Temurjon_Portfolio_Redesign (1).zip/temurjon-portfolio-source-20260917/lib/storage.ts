import "server-only";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";

export interface StorageProvider { save(file: File): Promise<string>; }

class LocalUploadStorage implements StorageProvider {
  async save(file: File) {
    const safe = file.name.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
    const name = `${Date.now()}-${randomBytes(4).toString("hex")}-${safe || "upload"}`;
    const directory = path.join(process.cwd(), "public", "uploads");
    await mkdir(directory, { recursive: true });
    await writeFile(path.join(directory, name), Buffer.from(await file.arrayBuffer()));
    return `/uploads/${name}`;
  }
}

export const storage: StorageProvider = new LocalUploadStorage();
