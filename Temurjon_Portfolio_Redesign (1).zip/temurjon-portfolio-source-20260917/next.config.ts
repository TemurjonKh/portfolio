import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Uploads are served from /uploads. If you move storage to Cloudinary or Vercel Blob,
  // add only that host here (e.g. { protocol: "https", hostname: "res.cloudinary.com" }).
  images: { formats: ["image/avif", "image/webp"], remotePatterns: [] },
  experimental: { serverActions: { bodySizeLimit: "10mb" } },
};

export default nextConfig;
