/**
 * Canonical portfolio copy. Used by `npm run db:seed` for fresh databases and by
 * `npm run content:update` to bring an existing database up to date (matched by title).
 */
const json = (values: string[]) => JSON.stringify(values);

export const profileCopy = {
  tagline: "I build systems that sense, decide, and act. Next, I want to take that into game AI.",
  aboutText: "I study Integrated Systems Engineering at Inha University as a Samsung Global Hope Scholar. My projects cover reinforcement learning agents, computer vision on small devices, biomedical signal processing, and databases. What connects them is building the whole pipeline, from input to decision to output. I plan to continue in graduate school at KAIST or SNU, focusing on AI for games.",
  kaggleUrl: "https://www.kaggle.com/temurjonkholmirzaev",
};

/** Bundled defaults, used only when the profile has no photo or Instagram link yet. */
export const defaultPhotoUrl = "/media/profile.jpg";
export const defaultInstagramUrl = "https://www.instagram.com/xolmirzayev_temurjon/";

export const quickFactUpdates = [
  { fromLabel: "Research field", label: "Heading toward", value: "Game AI research" },
];

export const skillGroups = [
  { label: "Machine learning", items: ["Python", "PyTorch", "Reinforcement learning (Q-learning, DQN, AlphaZero)", "MediaPipe"] },
  { label: "Games", items: ["Unity", "WebGL builds"] },
  { label: "Signals & hardware", items: ["MATLAB", "Signal processing", "Control systems", "Raspberry Pi", "Arduino"] },
  { label: "Web & data", items: ["MySQL", "PHP", "Bootstrap", "HTML", "Next.js", "Git"] },
];

type ProjectCopy = {
  title: string;
  matchTitles?: string[];
  role?: string | null;
  dateLabel?: string | null;
  status?: string | null;
  track: "games" | "ai" | "sensing" | "systems";
  visibility: "public" | "teaser";
  teaser?: string | null;
  stackTags: string[];
  description: string[];
  metrics: string[];
  githubUrl?: string | null;
  images?: string[];
  order: number;
};

export const projects: ProjectCopy[] = [
  {
    title: "Reinforcement learning on Tic-Tac-Toe: three agents compared",
    matchTitles: ["Reinforcement Learning Comparative Study — Tic-Tac-Toe"],
    role: "Personal project",
    track: "ai",
    visibility: "public",
    teaser: "Q-learning, DQN, and AlphaZero built from scratch and compared on the same game.",
    stackTags: ["Python", "PyTorch"],
    description: [
      "Implemented tabular Q-learning, DQN (replay buffer, target network), and AlphaZero (policy/value network with MCTS self-play) from scratch.",
      "On a game with 5,478 states, Q-learning trained in about 2 minutes and beat DQN, which needed reward shaping to learn blocking.",
      "AlphaZero learned from self-play alone, without any reward engineering.",
    ],
    metrics: ["AlphaZero win rate | 99%", "Q-learning win rate | 98%", "DQN win rate | 71%"],
    githubUrl: "https://github.com/TemurjonKh/rl-tictactoe",
    order: 0,
  },
  {
    title: "Uninvited",
    status: "In development",
    track: "games",
    visibility: "teaser",
    teaser: "A first-person strategy game for the browser, built in Unity. Its core is an AI opponent whose behavior players learn to read.",
    stackTags: [],
    description: [],
    metrics: [],
    images: ["/media/uninvited-cover.webp"],
    order: 1,
  },
  {
    title: "Smart hospital patient monitoring system",
    role: "Solo project, coursework",
    track: "sensing",
    visibility: "public",
    teaser: "Turns simulated heart, breathing, and pulse signals into alerts and live dashboards.",
    stackTags: ["MATLAB", "App Designer"],
    description: [
      "Simulated a hospital monitor that turns ECG, respiration, and PPG signals into alerts and live dashboards, using base MATLAB with no toolboxes.",
      "Flagged abnormal heart rhythm from the dominant frequency of the FFT, and removed 60 Hz interference and baseline wander with a two-stage zero-phase filter.",
      "Designed a PI controller for an IV infusion pump and checked its stability through pole locations, gain and phase margins, and the step response.",
      "Wrote all seven modules and the App Designer interface myself.",
    ],
    metrics: ["MATLAB files | 22", "60 Hz attenuation | ~35 dB"],
    githubUrl: "https://github.com/TemurjonKh/Smart-hospital-monitoring-system",
    order: 2,
  },
  {
    title: "GymEye: pose-estimation fitness assistant",
    matchTitles: ["GymEye — Pose-Estimation Fitness Assistant"],
    role: "Personal project",
    track: "sensing",
    visibility: "public",
    teaser: "A pan-tilt camera that follows you and tracks your pose while you exercise.",
    stackTags: ["Raspberry Pi 4", "MediaPipe", "Arduino"],
    description: [
      "Built a pan-tilt camera rig (Raspberry Pi 4 with an Arduino-driven servo mount) that follows a person for real-time pose tracking.",
      "Split the work between devices: the Pi captures video and the browser runs pose estimation, keeping feedback responsive.",
    ],
    metrics: [],
    githubUrl: "https://github.com/0C2L2/GymEye",
    images: ["/media/gymeye-1.jpg", "/media/gymeye-2.jpg"],
    order: 3,
  },
  {
    title: "Assistive navigation wearable",
    matchTitles: ["Spatial Audio Navigation Assistant"],
    status: "In development",
    track: "sensing",
    visibility: "teaser",
    teaser: "A wearable that helps blind and low-vision people move through unfamiliar places, using sound instead of sight.",
    stackTags: [],
    description: [],
    metrics: [],
    order: 4,
  },
  {
    title: "Airport management system",
    matchTitles: ["Database-Integrated Airport Management System"],
    role: "Team lead and database designer, Database Systems course",
    dateLabel: "Mar–Jun 2026",
    track: "systems",
    visibility: "public",
    teaser: "A MySQL database and PHP app for managing an airport's flights, bookings, and staff.",
    stackTags: ["MySQL", "PHP", "Bootstrap 5", "Git"],
    description: [
      "Designed a normalized schema that models employee types with ISA inheritance and foreign key constraints.",
      "Enforced business rules inside the database with triggers and stored procedures.",
      "Built a PHP back end with CRUD across 6 modules, plus session-based login with admin-only areas.",
    ],
    metrics: [],
    githubUrl: "https://github.com/TemurjonKh/db-airport_management_system",
    images: ["/media/airport-1.png", "/media/airport-2.png"],
    order: 5,
  },
];

export const volunteerUpdates = [
  {
    title: "Staff",
    org: "Try Everything (트라이 에브리싱)",
    dateLabel: "Sep 2026",
    images: ["/media/try-everything-1.jpg", "/media/try-everything-2.jpg", "/media/try-everything-3.jpg"],
    description: "Bilingual Korean–English volunteer staff at Try Everything Seoul, a startup event.\n\n• Helped startups present their ideas to investors\n• Interpreted between Korean and international founders, investors, and attendees\n• Guided participants and supported on-site operations",
  },
  {
    title: "Project Manager",
    org: "1365 Volunteer Portal",
    dateLabel: "Sep 2026",
    images: ["/media/sinwol-1.jpg", "/media/sinwol-2.jpg", "/media/sinwol-3.jpg"],
    description: "Led Team 17 of the Samsung Global Hope Scholarship in a two-hour session with elderly participants at the Seoul Sinwol Volunteer Center (Sep 11). Over three months, the team prepared activities around greetings from our home countries and drawing national landmarks. On the day, the participants turned it into a music and talent show.",
  },
];

export const toProjectData = (project: ProjectCopy) => ({
  title: project.title,
  role: project.role ?? null,
  dateLabel: project.dateLabel ?? null,
  status: project.status ?? null,
  track: project.track,
  visibility: project.visibility,
  teaser: project.teaser ?? null,
  stackTagsJson: json(project.stackTags),
  descriptionJson: json(project.description),
  metricsJson: json(project.metrics),
  githubUrl: project.githubUrl ?? null,
  order: project.order,
});
