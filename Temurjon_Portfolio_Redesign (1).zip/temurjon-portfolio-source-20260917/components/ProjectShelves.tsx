"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import { PiCaretLeft, PiCaretRight, PiX } from "react-icons/pi";
import { MediaCarousel } from "@/components/MediaCarousel";
import { normalizeTrack, trackLabel, TRACKS, youtubeId } from "@/lib/media";
import type { PortfolioProject } from "@/lib/content";

function Cover({ project }: { project: PortfolioProject }) {
  const first = project.images[0];
  if (first?.kind === "image") return <Image src={first.url} alt="" fill sizes="320px" className="tk-card__img" />;
  if (first?.kind === "video") return <video src={first.url + "#t=0.5"} muted playsInline preload="metadata" className="tk-card__img" aria-hidden="true" />;
  if (first?.kind === "youtube") {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={`https://i.ytimg.com/vi/${youtubeId(first.url)}/hqdefault.jpg`} alt="" className="tk-card__img" loading="lazy" />;
  }
  // No media: a generated cover with the project's initials over a small star field.
  const initials = project.title.split(/\s+/).filter(word => /^[A-Za-z]/.test(word)).slice(0, 2).map(word => word[0]).join("").toUpperCase();
  return (
    <span className={"tk-card__blank tk-card__blank--" + normalizeTrack(project.track)} aria-hidden="true">
      <span>{initials}</span>
    </span>
  );
}

function ProjectDetail({ project }: { project: PortfolioProject }) {
  const teaser = project.visibility === "teaser";
  return (
    <div className={"tk-detail" + (project.images.length ? " tk-detail--media" : "")}>
      <div>
        <p className="tk-project__meta">
          <span>{trackLabel(project.track)}</span>
          {project.status && <span className="tk-status">{project.status}</span>}
        </p>
        <h3 id="tk-dialog-title">{project.title}</h3>
        {(project.role || project.dateLabel) && <p className="tk-project__context">{[project.role, project.dateLabel].filter(Boolean).join(", ")}</p>}
        {teaser ? (
          <>
            {project.teaser && <p className="tk-project__teaser">{project.teaser}</p>}
            <div className="tk-redacted" aria-hidden="true"><i /><i /><i /></div>
            <p className="tk-project__note">Full details go public when it launches.</p>
          </>
        ) : (
          <>
            {project.description.length > 0 && <ul className="tk-project__points">{project.description.map(point => <li key={point}>{point}</li>)}</ul>}
            {project.metrics.length > 0 && (
              <dl className="tk-metrics">
                {project.metrics.map(metric => <div key={metric.label}><dt>{metric.label}</dt><dd>{metric.value}</dd></div>)}
              </dl>
            )}
            {project.stackTags.length > 0 && <ul className="tk-tags" aria-label="Tools">{project.stackTags.map(tag => <li key={tag}>{tag}</li>)}</ul>}
            {(project.githubUrl || project.demoUrl) && (
              <p className="tk-project__links">
                {project.demoUrl && <a className="tk-link" href={project.demoUrl} target="_blank" rel="noreferrer">Live demo</a>}
                {project.githubUrl && <a className="tk-link" href={project.githubUrl} target="_blank" rel="noreferrer">Source code</a>}
              </p>
            )}
          </>
        )}
      </div>
      <MediaCarousel title={project.title} items={project.images} />
    </div>
  );
}

function Shelf({ label, blurb, projects, onOpen }: { label: string; blurb: string; projects: PortfolioProject[]; onOpen: (project: PortfolioProject) => void }) {
  const railRef = useRef<HTMLUListElement>(null);
  const [edges, setEdges] = useState({ start: true, end: true });

  const measure = useCallback(() => {
    const rail = railRef.current;
    if (!rail) return;
    setEdges({ start: rail.scrollLeft < 4, end: rail.scrollLeft + rail.clientWidth > rail.scrollWidth - 4 });
  }, []);

  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [measure, projects.length]);

  const scroll = (direction: -1 | 1) => railRef.current?.scrollBy({ left: direction * railRef.current.clientWidth * 0.8, behavior: "smooth" });

  return (
    <section className="tk-shelf" aria-label={label}>
      <header className="tk-shelf__head">
        <div>
          <h3>{label} <span>{projects.length}</span></h3>
          <p>{blurb}</p>
        </div>
        {!(edges.start && edges.end) && (
          <div className="tk-shelf__arrows">
            <button type="button" onClick={() => scroll(-1)} disabled={edges.start} aria-label={`Scroll ${label} left`}><PiCaretLeft /></button>
            <button type="button" onClick={() => scroll(1)} disabled={edges.end} aria-label={`Scroll ${label} right`}><PiCaretRight /></button>
          </div>
        )}
      </header>
      <ul ref={railRef} className="tk-shelf__rail" onScroll={measure}>
        {projects.map(project => {
          const teaser = project.visibility === "teaser";
          const summary = project.teaser || project.description[0];
          return (
            <li key={project.id}>
              <button type="button" className={"tk-card" + (teaser ? " tk-card--teaser" : "")} onClick={() => onOpen(project)} aria-haspopup="dialog">
                <span className="tk-card__cover">
                  <Cover project={project} />
                  {project.status && <span className="tk-card__badge">{project.status}</span>}
                </span>
                <span className="tk-card__body">
                  <strong>{project.title}</strong>
                  {summary && <span className="tk-card__summary">{summary}</span>}
                  {!teaser && project.stackTags.length > 0 && <span className="tk-card__tags">{project.stackTags.slice(0, 3).join(" · ")}</span>}
                  <span className="tk-card__more">{teaser ? "Preview" : "View project"}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function ProjectShelves({ projects, openId, onOpenChange }: { projects: PortfolioProject[]; openId: string | null; onOpenChange: (id: string | null) => void }) {
  const open = projects.find(project => project.id === openId) ?? null;
  const ref = useRef<HTMLDialogElement>(null);

  // Native <dialog> gives focus trapping, Escape, the top layer and focus restore for free.
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    if (open && !element.open) element.showModal();
    if (!open && element.open) element.close();
  }, [open]);

  return (
    <>
      {TRACKS.map(track => {
        const items = projects.filter(project => normalizeTrack(project.track) === track.id);
        return items.length ? <Shelf key={track.id} label={track.label} blurb={track.blurb} projects={items} onOpen={project => onOpenChange(project.id)} /> : null;
      })}

      <dialog
        ref={ref}
        className="tk-dialog"
        aria-labelledby="tk-dialog-title"
        onClose={() => onOpenChange(null)}
        onMouseDown={event => event.target === event.currentTarget && onOpenChange(null)}
      >
        {open && (
          <div className="tk-dialog__panel">
            <button type="button" className="tk-dialog__close" onClick={() => onOpenChange(null)} aria-label="Close project"><PiX /></button>
            <ProjectDetail project={open} />
          </div>
        )}
      </dialog>
    </>
  );
}
